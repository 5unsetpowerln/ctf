#!/bin/bash
#
cd /home/cat_jump
exec 2>/dev/null
timeout 60 /home/cat_jump/cat_jump
